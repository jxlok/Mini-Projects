//
// Created by Jason Lok on 16/05/2021.
//

#include <stdio.h>
#include <stdlib.h>
#include "avg_and_max.h"
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#define SIZE 7

double test1[SIZE] = {-1.3, -1.45, -220, -100, -0.1, -0.1234, -200};
double test2[SIZE] =  {-1.3, 1.45, 220, 100, 0, 200, 0.1234};

void max_test(void)
{
    CU_ASSERT(max(test1, SIZE)== -0.1);
    CU_ASSERT(max(test2, SIZE)== 220);
}

void runAllTests()
{
    CU_initialize_registry();
    CU_pSuite suite = CU_add_suite("max_suite", 0, 0);
    CU_add_test(suite, "max_test", max_test);
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

}

int main(){
    runAllTests();
    return 0;
}

double max(double array[], int size)
{
    double max = array[0];

    for (int i = 0;  i < size;  i++)
    {
        if(max < array[i])
            max = array[i];
    }

    return max;
}
