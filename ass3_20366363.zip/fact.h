/* 
 * File:   fact.h
 * Author: JD
 *
 * 
 */

long factorial(int size);
