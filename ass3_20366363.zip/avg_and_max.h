//
// Created by Jason Lok on 16/05/2021.
//

#ifndef ASS3Q1_C_AVG_AND_MAX_H
#define ASS3Q1_C_AVG_AND_MAX_H

/*
 * File:   avg_and_max.h
 * Author: JD
 *
 *
 */

double max(double array[], int size);

double average(double array[], int size);

#endif //ASS3Q1_C_AVG_AND_MAX_H
