//
// Created by Jason Lok on 16/05/2021.
//

#include "fact.h"
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>

void factorial_test(void)
{
    CU_ASSERT(factorial(0)== 1);
    CU_ASSERT(factorial(1)== 1);
    CU_ASSERT(factorial(4)== 24);
    CU_ASSERT(factorial(6)== 720);
}

void runAllTests()
{
    CU_initialize_registry();
    CU_pSuite suite = CU_add_suite("factorial_suite", 0, 0);
    CU_add_test(suite, "factorial_test", factorial_test);
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

}

int main(){
    runAllTests();
    return 0;
}

long factorial(int size)
/*  This function assumes that the argument is non-negative, ie >= 0.*/
{
    int i;
    long fact;

    fact = 1;

    for (i = 1;  i <= size;  i++)
    {
        fact *= i;
    }

    return fact;
}
