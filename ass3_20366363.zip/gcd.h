//
// Created by Jason Lok on 16/05/2021.
//

#ifndef ASS3Q1_C_GCD_H
#define ASS3Q1_C_GCD_H

int gcd(int a, int b);

#endif //ASS3Q1_C_GCD_H
