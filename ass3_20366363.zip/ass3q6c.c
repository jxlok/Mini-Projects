//
// Created by Jason Lok on 16/05/2021.
//

#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include "gcd.h"

void gcd_test(void)
{
    CU_ASSERT(gcd(42, 56) == 14);
    CU_ASSERT(gcd(48, 18) == 6);
    CU_ASSERT(gcd(270, 192) == 6);
    CU_ASSERT(gcd(1237, 24) == 1);
    CU_ASSERT(gcd(4200000, 3780000) == 420000);
    CU_ASSERT(gcd(0, 0) == 0);
}

void runAllTests()
{
    CU_initialize_registry();
    CU_pSuite suite = CU_add_suite("gcd_suite", 0, 0);
    CU_add_test(suite, "gcd_test", gcd_test);
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

}

int main(){
    runAllTests();
    return 0;
}

int gcd(int a, int b){

    if(b==0){
        return a;
    }
    else{
        return gcd(b, a%b);
    }

}
