//
// Created by Jason Lok on 16/05/2021.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "avg_and_max.h"
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#define SIZE 7

double test1[SIZE] = {-1.3, -1.45, -220, -100, -0.1, -0.1234, -200};
double test2[SIZE] = {-1.3, 1.45, 220, 100, 0, 200, 0.1234};

void average_test(void)
{
    CU_ASSERT_DOUBLE_EQUAL(average(test1, SIZE), -74.7104857142857, 13);
    CU_ASSERT_DOUBLE_EQUAL(average(test2, SIZE), 74.3247714285714, 13);
}

void runAllTests()
{
    CU_initialize_registry();
    CU_pSuite suite = CU_add_suite("average_suite", 0, 0);
    CU_add_test(suite, "average_test", average_test);
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

}

int main(){
    runAllTests();
    return 0;
}

double average(double array[], int size)
{
    double sum = 0;

    for (int i = 0;  i < size;  i++)
    {
        sum += array[i];
    }

    return sum/size;
}
